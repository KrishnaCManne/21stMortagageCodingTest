﻿using Prism.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace _21stMortgageInterviewApplication
{
    public class MainViewModel : Window, INotifyPropertyChanged
    {
        public MainViewModel()
        {

        }

        #region largest Value
        public ICommand BtnLargestVal_Command
        {
            get { return new DelegateCommand<object>(Execute_LargestVal, IsExecuteLargestVal); }
        }

        private void Execute_LargestVal(object context)
        {
            List<int> Vals = InputText.Split(',').Select(int.Parse).ToList();
            ResultText = Vals.Max().ToString();
        }

        private bool IsExecuteLargestVal(object context)
        {
            return true;
        }
        #endregion largest Value

        #region Sum of Odd
        public ICommand BtnSumOddNum_Command
        {
            get { return new DelegateCommand<object>(Execute_SumOdd, IsExecuteSumOdd); }
        }

        private void Execute_SumOdd(object context)
        {
            int Sum = 0;
            List<int> Vals = InputText.Split(',').Select(int.Parse).ToList();
            foreach (var val in Vals)
            {
                if (val % 2 != 0)
                {
                    Sum += val;
                }
            }

            ResultText = Sum.ToString();
        }

        private bool IsExecuteSumOdd(object context)
        {
            return true;
        }
        #endregion Sum of Odd

        #region Sum of Even

        public ICommand BtnSumEvenNum_Command
        {
            get { return new DelegateCommand<object>(Execute_SumEven, IsExecuteSumEven); }
        }

        private void Execute_SumEven(object context)
        {
            int Sum = 0;
            List<int> Vals = InputText.Split(',').Select(int.Parse).ToList();
            foreach (var val in Vals)
            {
                if (val % 2 == 0)
                {
                    Sum += val;
                }
            }

            ResultText = Sum.ToString();
        }

        private bool IsExecuteSumEven(object context)
        {
            return true;
        }
        #endregion Sum of Even

        public string InputText { get; set; }

        private String _ResultText;
        public String ResultText
        {
            get { return _ResultText; }
            set
            {
                if (_ResultText == value)
                    return;

                _ResultText = value;
                OnPropertyChanged("ResultText");
            }
        }

        private static readonly Regex _regex = new Regex("^[-,0-9]+$"); //regex that matches disallowed text

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (handler != null)
            {
                var e = new PropertyChangedEventArgs(propertyName);
                handler(this, e);
            }
        }

        private static bool IsTextAllowed(string text)
        {
            if (text != null)
                return !_regex.IsMatch(text);
            else
                return false;
        }

        protected bool SetProperty<T>(ref T field, T newValue, [CallerMemberName] string propertyName = null)
        {
            if (!Equals(field, newValue))
            {
                field = newValue;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
                return true;
            }

            return false;
        }
    }
}
